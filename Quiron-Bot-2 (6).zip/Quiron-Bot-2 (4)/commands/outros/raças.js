{
  module.exports = [{
    name: "raças",
    aliases: ['raça', 'espécies', 'espécie'],
    code: `
$image[1;https://i.imgur.com/UWArQH9.png]
$addSelectMenu[1;racas;Escolha uma raça para saber mais!;1;1;no;Semideuses/Meio-sangues:Descubra mais sobre os Semideuses/Meio-sangues!:semideus;Sátiros:Descubra mais sobre os Sátiros!:satiros]
$footer[2;Staff - $serverName;$serverIcon]
$image[2;https://c.tenor.com/O1a2K3XZAPkAAAAC/sick-boy-matheus-percy-jackson.gif]
$description[2;Espalhadas pelo mundo mitológico de Percy Jackson, existem inúmeras raças as quais você pode ser, Sátiros, Semideuses e até Ninfas e Centauros!]
$author[2;$serverName;$serverIcon]
`
  }, {
    //Semideuses/Meio-Sangues
    name: "racas",
    type: "interaction",
    prototype: "selectMenu",
    code: `
  $interactionReply[;{newEmbed:{author:$serverName:$serverIcon}{title:Semideuses/Meio-Sangues}{description:
\`\`\`Sobre:\`\`\`
> ・"Semideuses" ou "meio-sangues" são os filhos dos deuses com parceiros mortais. Eles normalmente se destacam por serem mais fortes e habilidosos que os humanos normais. Os semideuses podem comer e tomar Ambrosia e Néctar, respectivamente, alimentos dos deuses (porém com moderação) e têm poderes e habilidades relacionadas com o domínio dos seus pais divinos. Por exemplo: filhos(as) de Atena/Minerva têm grande habilidade para estratégias, filhos(as) de Ares/Marte têm especialidade em lutas, filhos(as) de Hades/Plutão tem afinidade com os mortos ou mesmo com a riqueza, filhos(as) de Poseidon ou Netuno com água, filhos(as) de Zeus/Júpiter com os céus e por ai vai...
> ・Eles normalmente são escoltados até o Acampamento Meio-Sangue por um sátiro e lá são acomodados em chalés referentes a seus pais, após serem reconhecidos pelos mesmos. Por exemplo: Annabeth vivia no chalé de Atena, Clarisse vivia no chalé de Ares e Leo vivia no chalé de Hefesto. Percy ficou vivendo no chalé de Hermes antes de ser reconhecido por seu pai, Poseidon. Hermes é o deus dos viajantes, então todos aqueles que não são reconhecidos por seus pais também acabam ficando lá.

\`\`\`F.A.Q:\`\`\`
> ・ **É uma raça que poder ter magia?** Sim, filhos de Hécate conseguem praticar magia, mas apenas eles.
> ・ **Aonde posso achar os poderes dos semideuses?** No canal <#964295716568719380>!
> ・ **Vão ser sempre as mesmas habilidades e poderes?** Sim, não há registro de que os semideuses filhos de um(a) mesmo(a) pai/mãe divino(a) que tiveram habilidades e poderes diferentes. Há alguns casos aonde os semideuses podem receber bençãos e ganharem novos poderes, mas isso é bem raro.

\`\`\`Desvantagens da Raça:\`\`\`
> ・Semideuses atraem muitos monstros e sua vida nunca será totalmente tranquila.
}{color:#99abbe}{image:https://i.imgur.com/Nyr10BE.gif}{footer:Staff - $serverName:$serverIcon}};;;all;true]
  $onlyIf[$interactionData[values[0]]==semideus]
`
  }, {
    //Sátiros
    name: "racas",
    type: "interaction",
    prototype: "selectMenu",
    code: `
  $interactionReply[;{newEmbed:{author:$serverName:$serverIcon}{title:Sátiros}{description:
\`\`\`Sobre:\`\`\`
> ・Sátiros são criaturas metade homem, e metade bode da cintura para baixo. São descritos como deuses menores responsáveis por zelar pelas florestas e bosques, mas apesar de serem considerados deuses, eles não são imortais. Eles são extremamente ligados com o Deus da Natureza, Pã, nascendo com a vontade de encontra-lo. Os sátiros conseguem canalizar a energia da natureza tocando canções através de flautas de bambu, sendo que através dessas canções eles podem afetar o estado emocional de indivíduos ou fazer crescer plantas para imobilizar. Eles também têm a habilidade de conceder bençãos a animais, para conduzi-los de forma segura até seus habitats.

\`\`\`F.A.Q:\`\`\`
> ・ **É uma raça que poder ter magia?** Sim, mas um tipo de magia super limitada, com apenas alguns feitiços específicos disponíveis.
> ・ **Aonde posso achar os poderes dos Sátiros?** No canal <#964295716568719380>!
> ・ **Vão ser sempre as mesmas habilidades e poderes?** Sim, mas você ainda sim pode fazer com que seu personagem tenham uma área dentro dos poderes e habilidades de um Sátiro na qual ele ou ela é muito bom.

\`\`\`Desvantagens da Raça:\`\`\`
> ・Alguns monstros podem aterrorizar os Sátiros, como a Medusa, Ciclopes, etc... 
> ・Pernas de cabra, elas não são muito bem vistas no mundo dos mortais então tente esconde-las em missões que envolvam sair do acampamento!
}{color:#96bf48}{image:https://i.pinimg.com/originals/47/53/39/47533938fc0b5683c47fff9db33b4cf8.gif}{footer:Staff - $serverName:$serverIcon}};;;all;true]
  $onlyIf[$interactionData[values[0]]==satiros]
`
  }]
}