
{
  module.exports = [
    {
      name: "defeitos",
      code: `
$author[$serverName;$serverIcon]
$title[Defeitos Mortais]
$description[Os Defeitos Mortais, ou Falhas Fatais, são aqueles defeitos pessoais que todo herói tem. Sempre, um semideus terá uma falha fatal em seu eu, algo que deve controlar e saber ordenar, se não, como se diz no nome, pode ser fatal para sua vida. Existem vários tipos de defeitos mortais, e geralmente os semideuses tendem a ter algo relacionado a personalidade de seus pais.

**Ω Húbris Ω**
\`\`\`Se sente capaz de corrigir não só os seus mais os erros das outras pessoas também, refazendo decisões e atitudes para fazer melhor que tudo e todos. O orgulho, e a arrogância definem seu comportamento em maior parte parte do tempo, incluindo temperamentalismo e falta de paciência em parte do tempo.\`\`\`

**Ω Grudge Ω**
\`\`\`Guarda todas aquelas mágoas que lhe são ocasionadas pela vida. É rancoroso e não gosta de demonstrar suas emoções negativas, ou seja, se repreende e vez por outra torna-se agressivo com as pessoas, mas depois se arrepende, mas não com aqueles que lhe magoaram, em maioria das vezes.\`\`\`

**Ω Ambition Ω**
\`\`\`Em maior parte do tempo você deseja ser ou ao menos parecer ser o mais poderoso de todos nos lugares que vai, e faz de tudo para que o conseguir alcançar. Quer sempre tomar as rédeas da situação e isso o torna controlador, algo que muitas vezes não é bom, e o torna um péssimo integrante de equipes. Está sempre em busca de superar os outros na sua fama, na força de personalidade, e no poder.\`\`\`

**Ω Allegiance Ω**
\`\`\`É excessivamente fiel a seus amigos e familiares e arrisca sua própria vida por eles em qualquer hipótese. Se torna alguém impulsivo as vezes e muito confiante de sí, o que pode lhe trazes frustrações ao longo da vida. Quebra regras quando é impedido de fazer algo por eles e se põe em risco por tais atitudes ''rebeldes''.\`\`\`

**Ω Understimate Ω**
\`\`\`Não gosta de aparecer, se sente muitas vezes menos do que os outros em todos os aspectos, acaba não se dando o valor devido. Guarda um sentimento de inferioridade, e chega a não confiar em si mesmo para algo que lhe trará fama ou admiração. Se subestima sempre.\`\`\`

**Ω Vanity Ω**
\`\`\`Você é extremamente vaidoso quanto a sua aparência principalmente física, e quer estar com tudo em cima em qualquer situação. Se torna exigente em algumas situações e as vezes acha que é o centro das atenções, chegando a ser considerado fútil. \`\`\`

**Ω Curio Ω**
\`\`\`O defeito da curiosidade, algo que se torna muito perigoso se não o controlar, até mesmo em relação a sua reputação que é dita por falar e querer saber dos outros e das coisas que não lhe pertencem. O caso típico de Pandora, cuja curiosidade a fez perder a vida que tinha ao abrir a caixa. \`\`\`]
$addButton[1;❓ Pedir Ajuda;link;https://discord.com/channels/1086836441604177960/1087474866791391332;no]
$image[https://i.imgur.com/KM7bsp2.gif]
$footer[Staff - 🔱 • Olimpianos: Crônicas Meio-Sangue - RP;$serverIcon]
            `
    }
  ]
}