module.exports = [{
  name: "$alwaysExecute",
  code: `
$if[$getChannelVar[webhookInfoID]!=0;{execute:sendChar}]
$if[$getChannelVar[webhookInfoID]==0;{execute:createBruxohook}]
$onlyIf[$getUserVar[nomePerso]!=Não Definido]
$onlyIf[$checkContains[$message;//]==false]
$onlyForCategories[1086836448457670818;1086836448730296428;1086836449028087808;1086836449028087810;1086836449300725792;1086836449300725799;]
`
}, {
  name: "createBruxohook",
  type: "awaited",
  code: `
$sendWebhookMessage[$getChannelVar[webhookInfoID];$getChannelVar[webhookInfoToken];$message]
$setChannelVar[webhookInfoID;$splitText[1]]
$setChannelVar[webhookInfoToken;$splitText[2]]
$textSplit[$get[webhook]; , ]
$let[webhook;$createWebhook[$channelID;Bruxohook;$serverIcon]]
`
}, {
  name: "sendChar",
  type: "awaited",
  code: `
$deletecommand
$bruxohook[$nonEscape[$authorID];$getChannelVar[webhookInfoID];$getChannelVar[webhookInfoToken];$channelID;$messageID;$nonEscape[$getUserVar[nomePerso]]・[ $nonEscape[$getUserVar[vidaPerso]]/25HP ];$nonEscape[$getUserVar[fotoPerso]];$nonEscape[$message];$referenceMessageID;$nonEscape[$getMessageVar[webhookNameMsg;$referenceMessageID]];$nonEscape[$getMessageVar[webhookAuthorMsg;$referenceMessageID]]]
`
}]