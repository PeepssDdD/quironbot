{
  module.exports = [{
    name: "poderes",
    aliases: ['habilidades', 'poder', 'habilidade'],
    code: `
$image[1;https://i.imgur.com/1cAZw43.png]
$addSelectMenu[1;poderes;Veja os poderes de cada raça e semideus abaixo!;1;1;no;Sátiros:Descubra mais sobre as habilidades e poderes dos Sátiros!:satiro;Zeus:Descubra mais sobre as habilidades e poderes dos filhos(as) de Zeus!:zeus:no:⚡;Poseidon:Descubra mais sobre as habilidades e poderes dos filhos(as) de Poseidon!:poseidon:no:🔱;Deméter:Descubra mais sobre as habilidades e poderes dos filhos(as) de Deméter!:demeter:no:🌾;Ares:Descubra mais sobre as habilidades e poderes dos filhos(as) de Ares!:ares:no:🪖;Atena:Descubra mais sobre as habilidades e poderes dos filhos(as) de Atena!:atena:no:🦉;Apolo:Descubra mais sobre as habilidades e poderes dos filhos(as) de Apolo!:apolo:no:🌞;Hefesto:Descubra mais sobre as habilidades e poderes dos filhos(as) de Hefesto!:hefesto:no:🔥;Afrodite:Descubra mais sobre as habilidades e poderes dos filhos(as) de Afrodite!:afrodite:no:💖;Hermes:Descubra mais sobre as habilidades e poderes dos filhos(as) de Hermes!:hermes:no:📨;Dionísio:Descubra mais sobre as habilidades e poderes dos filhos(as) de Dionísio!:dionisio:no:🍷]
$footer[2;Staff - $serverName;$serverIcon]
$image[2;https://i.imgur.com/ap5xGvJ.gif]
$description[2;• Espalhadas pelo mundo mitológico de Percy Jackson, existem inúmeras raças as quais você pode ser, Sátiros, Semideuses e até Ninfas e Centauros, com vários poderes e habilidades distintas, que tal dar uma conferida neles? Atualmente só estão disponíveis as seguintes raças: \`Sátiros\` e \`Semideuses\`.]
$author[2;$serverName;$serverIcon]
`
  }, {
    //Sátiro
    name: "poderes",
    type: "interaction",
    prototype: "selectMenu",
    code: `
  $interactionReply[;{newEmbed:{author:$serverName:$serverIcon}{title:Habilidades Passivas - Sátiros}{description:**COMO UM DELES**
 - Poderá falar com qualquer tipo de animal, podendo o entender e ser entendido pelo mesmo.

**MESTRE AGRÍCOLA**
 - Saberá exatamente como plantar, cuidar e colher qualquer tipo de planta existente.

**INSTRUMENTISTA**
 - Os sátiros não são conhecidos por seu comportamento agressivo, mas sim por viverem dentre a natureza tocando uma flauta e festejando junto a animais, por isso nesse nível o sátiro saberá exatamente como usar uma flauta podendo fazer músicas tanto normais como mágicas.

**ESTÔMAGO DE FERRO**
 - Poderá se alimentar de qualquer material orgânico ou não orgânico, seu estômago e totalmente capaz de diretor até mesmo pregos.}{footer:Staff - $serverName:$serverIcon}}{newEmbed:{author:$serverName:$serverIcon}{title:Habilidades Ativas - Sátiros}{description:**LOCALIZAÇÃO POR BOLOTAS (Habilidade Base)**
 - Os sátiros sempre carregam bolotas que são utilizadas quando eles estão perdidos. Eles arrumam as bolotas no chão enquanto tocam uma suave melodia em sua flauta. As bolotas se arrumam de um jeito que mostram o caminho certo a se seguir, fazendo com que o sátiro não se perca.

**DANÇA DO TEMPO (Habilidade Base)**
 - Podendo realizar a dança que muda o tempo, o sátiro pode causar de um simples sereno, até granizos e chuvas grandiosas.

**BENÇÃO DO SÁTIRO (Maestria Baixa)**
 - É uma benção por meio de uma demorada e suave melodia que garante uma livre passagem dos sátiros e quem estiver com eles por meio de locais onde talvez possam haver animais selvagens.

**PEQUENOS ALIADOS (Maestria Baixa)**
 - Poderá invocar até 2 animais de pequeno porte (não mágicos) para lutar ao seu lado ao tocar uma flauta.

**RAÍZ OFENSIVA (Maestria Média)**
 - Faz com que raízes resistentes se lançem da terra, agarrando o oponente pelos tornozelos. Quanto mais treino, mais velozes ficam as raízes e mais resistentes. Essa melodia, precisa de dois turnos. Um para tocar a flauta e outro para que as raízes subam do solo pendendo o inimigo.

**CHOQUE (Maestria Média)**
 - Os chifres irão ter uma camada de feita de energia a sua volta, ele será comprido e com ponta afiada.

**FLAUTA CURATIVA (Maestria Alta)**
 - Ao tocar uma música calma com sua flauta fará um aliado ser coberto por uma aura verde que irá o curar em 70 de vida.

**FAÇA PARTE DA FAUNA (Maestria Máxima)**
 - Quando tocar uma música chamada como proibida fará raízes saírem do chão e se enrolarem em seu adversário, essas raizes começarão a se tornar um tronco e encherá de folhas e logo o adversário irá se tornar um Carvalho por completo.}{footer:Staff - $serverName:$serverIcon}};;;all;true]
  $onlyIf[$interactionData[values[0]]==satiro]
`
  }, {
    //Zeus
    name: "poderes",
    type: "interaction",
    prototype: "selectMenu",
    code: `
  $interactionReply[;{newEmbed:{author:$serverName:$serverIcon}{title:Habilidades Passivas - Filhos(as) de Zeus}{description:**IMUNIDADE A ELETRICIDADE**
 - Filhos(as) de Zeus são imunes a eletricidade.

**ABSORÇÃO DE ELETRICIDADE**
 - Filhos(as) de Zeus além de serem imunes, absorvem a eletricidade que são lançados contra eles.

**ELETRICIDADE ESTÁTICA**
 - Filhos(as) de Zeus podem gerar eletricidade estática dependendo de suas emoções.}{footer:Staff - $serverName:$serverIcon}}{newEmbed:{author:$serverName:$serverIcon}{title:Habilidades Ativas - Filhos(as) de Zeus}{description:**AEROCINESE (Habilidade Base)**
 - Filhos(as) de Zeus podem controlar o ar como bem entenderem.

**ELETROCINESE (Habilidade Base)**
 - Filhos(as) de Zeus podem controlar e gerar eletricidade como bem entenderem.

**ATMOCINESE (Habilidade Base)**
 - Filhos(as) de Zeus podem controlar o clima em pequenas escalas, juntamente disso também conseguem criar e invocar nuvens.

**CONJURAÇÃO DE RAIOS (Maestria Baixa)**
 - Filhos(as) de Zeus podem fazer uma oração ao seu pai, e invocar raios para acertar os seus inimigos.

**ÚLTIMO SUSPIRO (Maestria Média)**
 - Filhos(as) de Zeus podem criar vórtices de ar ao redor de seus inimigos, fazendo eles perderem forças.

**BENÇÃO DA TORMENTA (Maestria Alta)**
 - Filhos(as) de Zeus podem fazer uma oração ao seu pai e adquirir o poder de invocar tornados e tempestades por um curto período de tempo.

**FÚRIA DO DIVINO (Maestria Máxima)**
 - Filhos(as) de Zeus podem invocar as forças de seu pai, podendo invocar seus raios para atirar diretamente nos inimigos. Apesar de tamanho poder, não podem invocar o raio-mestre de seu pai, por ser poderoso demais.}{footer:Staff - $serverName:$serverIcon}};;;all;true]
  $onlyIf[$interactionData[values[0]]==zeus]
`
  }, {
    //Poseidon
    name: "poderes",
    type: "interaction",
    prototype: "selectMenu",
    code: `
  $interactionReply[;{newEmbed:{author:$serverName:$serverIcon}{title:Habilidades Passivas - Filhos(as) de Poseidon}{description:**ZOOLINGUISMO**
 - Filhos(as) de Poseidon são capazes de se comunicar telepatica e empaticamente com equinos, seres marinhos e semelhantes.

**AUTORIDADE AQUÁTICA**
 - Filhos(as) de Poseidon, herdando a autoridade de seu pai, são vistos como superiores nos seus territórios e tem controle sobre os seus súditos.

**IMUNIDADE AQUÁTICA**
 - Filhos(as) de Poseidon, com essa espécie de imunidade, são imunes à pressão da água, à morte por afogamento e também teram a resistência aumentada quando em contato com água, ainda mais se esta for salgada (isso também se aplica a cura e a regeneração de lesões, envenenamentos etc.). 

**AMFÍBIO**
- Filhos(as) de Poseidon possuem a capacidade de nadarem mais rápidos que qualquer outra pessoa, assemelhando-se à peixes e ambíbios. Portanto, também respiram em baixo d'água, podem pular de grandes alturas (desde que caiam na água, não sofrerão lesões), não molham si mesmo ou suas roupas caso não queiram e também podem criar pequenas bolhas, — difudindo o oxigênio da água —, assim servindo como máscaras respiratórios para seus aliados

  Hab. Base#COLON# Nadam, anerobicamente, até 80 km/h. 

  Maestria Baixa#COLON# Nadam, anaerobicamente, até 120 km/h. 

  Maestria Média#COLON# Nadam, anaerobicamente, até 180 km/h. 

  Maestria Alta#COLON# Nadam, anaerobicamente, até 260 km/h. 

  Maestria Máxima#COLON# Nadam, anaerobicamente, até 340 km/h. 

**GEOLOCALIZAÇÃO**
- Filhos(as) de Poseidon podem se localizar quando em meio ao mar, sabendo exatamente suas coordenadas, distâncias em milhas náuticas etc.}{footer:Staff - $serverName:$serverIcon}}{newEmbed:{author:$serverName:$serverIcon}{title:Habilidades Ativas - Filhos(as) de Poseidon}{description:**HIDROCINESE (Habilidade Base)**
 - Filhos(as) de Poseidon podem controlar a água pré-existente e os seus mais variados estados como bem entenderem.

**FÚRIA DE POSEIDON**
 - Filhos(as) de Poseidon podem gerar terremotos, maremotos e até mesmo erupções vulcânicas, impulsiva ou propositalmente.

  Hab. Base: Podem gerar pequenos tremores na Terra, algo que no máximo pode desestabilizar animais de pequeno porte e crianças.

  Maestria Baixa: Podem gerar tremores que chegam a desestabilizar animais de médio porte e humanos com o peso normal.

  Maestria Média: Podem gerar tremores que chegam a abrir pequenas rachaduras no solo e são capazes de desestabilizar animais de grande porte e qualquer humano. Levantam pequenas ondas.

  Maestria Alta: Podem gerar tremores que são capazes de desestabilizar completamente animais como elefantes e hipopótamos e pequenas estruturas. Levantam grandes ondas

  Maestria Máxima: Podem gerar tremores que são capazes de desestabilizar qualquer animal terrestre e grandes estruturas. São capazes até mesmo de ativar pequenos vulcões.

**CONDENSAÇÃO DE UMIDADE (Maestria Baixa)**
 - Filhos(as) de Poseidon podem retirar água do ar, ou de outras fontes, e as manipula-las ao seu bel prazer.

**ÁGUAS TRAÇOEIRAS (Maestria Média)**
 - Filhos(as) de Poseidon podem criar armadilhas que são capazes de prender e afogar por um período de tempo inimigos que entrem em uma específica parte da água.

**IRA DOS CÉUS (Maestria Alta)**
 - Filhos(as) de Poseidon podem causar grandes e perigosas tempestades marítimas, que quando estão no "interior" do mar são tão fortes quanto as geradas por filhos de Zeus.

**SENHOR DA VIDA (Maestria Máxima)**
 - Filhos(as) de Poseidon, sabendo que a água está presente no corpo de todos os seres vivos, ganha um poder sobre algum animal, planta ou um humano. Assim, é capaz de desidratar seu oponente a ponto de desmaia-lo ou mata-lo, sugar a sua "energia", dominar os seus movimentos etc. Depende da criatividade do usuário. Só se pode utilizar uma vez por rodada de turnos e gera grande desgaste.}{footer:Staff - $serverName:$serverIcon}};;;all;true]
  $onlyIf[$interactionData[values[0]]==poseidon]
`
  }, {
    //Deméter
    name: "poderes",
    type: "interaction",
    prototype: "selectMenu",
    code: `
  $interactionReply[;{newEmbed:{author:$serverName:$serverIcon}{title:Habilidades Passivas - Filhos(as) de Deméter}{description:**GRANDE MANEJO DA FOICE**
 - Deméter é representada carregando uma foice, então seus filhos terão grande manejo desta.

**CONHECIMENTO DE VENENOS E TOXINAS**
 - Deméter é a deusa da plantação, assim terá grande conhecimento sobre essas plantas e substâncias feitas a partir destas, o que irá englobar vários tipos de venenos, que são feitos ou misturados a substâncias provenientes de plantas. Assim, a deusa terá conhecimento sobre venenos, conhecimento este que será passado para seus filhos. O mesmo vale para certas toxinas.

**DEDO VERDE**
 - Deméter tem como seu símbolo as sementes, a representação do começo da vida de uma planta para muitas plantas. O semideus poderá fazer essas sementes germinarem e as plantas nascerem.

**UM SÓ COM A NATUREZA**
- O semideus tem uma profunda ligação com a natureza, podendo interagir com as plantas e com os animais.

**UM LUGAR SEGURO (Maestria Alta)**
- O semideus, em um momento de desespero, pode ser envolvido por raízes e levado por elas, através do subsolo, para uma localização segura enquanto deixa uma flor para trás. Essa habilidade pode servir para o grupo que estiver com o semideus. Essa habilidade pode ser utilizada apenas uma vez por evento.}{footer:Staff - $serverName:$serverIcon}}{newEmbed:{author:$serverName:$serverIcon}{title:Habilidades Ativas - Filhos(as) de Deméter}{description:**MANIPULAÇÃO DE MADEIRA (Habilidade Base)**
- O semideus pode manipular a madeira de uma maneira bastante livre.

Habilidade Base: No começo, o semideus precisa se concentrar para manipular a madeira, não podendo manipular a madeira das árvores ainda vivas, somente aquelas mortas, ou seja, móveis, gravetos e uma árvore derrubada, mas ainda assim, seu controle sobre ela ainda é de pequena escala.

Maestria Baixa: Mais forte, o semideus pode manipular a madeira em uma escala maior do que antes, podendo manipular em uma escala mínima a madeira de árvores vivas e podendo manipular em média escala madeira "morta". Ainda precisa de concentração para tal, mas muito menos do que antes.

Maestria Média: Neste nível, o semideus pode manipular a madeira em uma escala maior do que antes, podendo manipular em escala média madeira de árvores vivas e podendo manipular em grande escala madeira "morta". A atenção requerida para essa habilidade agora é mínima.

Maestria Alta: Agora, o semideus pode manipular a madeira em uma escala maior do que antes, podendo manipular madeira em uma grande escala e com grande facilidade. Ele já pode fazer madeira crescer do seu corpo ou numa superfície qualquer, estando em contado com a mesma, mas a geração deles e mínima.

Maestria máxima: No seu máximo, o semideus já pode manipular madeira em grande escala, podendo produzir a sua madeira na quantidade que precisar.

**GEOCINESE (Habilidade Base)**
 - O semideus, através de seus fortes laços com as plantas, estabeleceu uma especial conexão com a terra.

Habilidade base: O semideus, à princípio, poderá controlar minimamente a terra, precisando de muito esforço e concentração para fazê-lo, podendo controlar em pequena escala.

Maestria baixa: Agora, o semideus poderá se concentrar menos para manipular a terra e gastará menos energia ao fazê-lo, mas ainda controlará em pequena escala.

Maestria média: Mais forte, o semideus pode manipular a terra em média escala, gastando o mesmo nível de concentração e de energia para tal.

Maestria Alta: Neste nível, o semideus pode manipular a terra em média escala, gastando o mínimo de concentração e energia para isso.

Maestria máxima: No seu máximo, o semideus poderá controlar a terra em grande escala, gastando o mesmo nível de concentração e energia de antes.

**CLOROCINESE (Habilidade Base)**
- Por ser filho(a) da deusa da agricultura, ele tem controle sobre plantas e sementes, podendo fazer elas crescerem, florescerem ou nascerem.

**EM MEIO A NATUREZA (Maestria Baixa)**
- O semideus, devido às sua grande ligação com as plantas e, por consequência, com a natureza, pode se misturar à mesma, "se tornando um" com ela, pelo menos na aparência.

**UNIDADE DA NATUREZA (Maestria Média)**
- O semideus concentrará sua energia e a enviará para as árvores próximas (caso não tenha árvores na região, será criada uma minifloresta pelo tempo que a habilidade estiver sendo executada, desaparecendo logo após o fim do ataque), que avançarão contra o inimigo e o perseguirá até o prender, o imobilizando. Espíritos da natureza serão atraídos para o local e atacarão o inimigo, causando danos físicos e espirituais ao alvo. Os espíritos, após o ataque, irão embora.

**RAIO DE GIRASSOL (Maestria Alta)**
- O semideus invocará um a dois que se assemelha ao girassol, que concentrará rapidamente energia e a liberará em um raio de energia.

**SERVO DE PLANTAS **
-O semideus poderá criar um servo feito de plantas e videiras à sua imagem e semelhança, tendo certas habilidades.

Força: Ele terá a força de 4 filhos de Ares no mesmo nível que o semideus.
Velocidade: Ele poderá se mover a 300 km/h.
Resistência: Ele terá a resistência de um filho de Ares no mesmo nível que o semideus.

Maestria Alta: O semideus poderá criar um servo.

Maestria Máxima: O semideus poderá criar três servos.}{footer:Staff - $serverName:$serverIcon}};;;all;true]
  $onlyIf[$interactionData[values[0]]==demeter]
`
  }, {
    //Ares
    name: "poderes",
    type: "interaction",
    prototype: "selectMenu",
    code: `
  $interactionReply[;{newEmbed:{author:$serverName:$serverIcon}{title:Habilidades Passivas - Filhos(as) de Ares}{description:**SUPER FORÇA**
 - Semelhante a sua velocidade os filhos de Ares mantêm uma força naturalmente divina se for comparada ao de semideuses equivalentes em poder ao mesmo, rivalizando com os filhos de Tyr, Heimdall e Thor por exemplo. Seus músculos independente do quão severa seja sua batalha não atrofia ou mesmo chega a um limite natural, conseguindo manter uma batalha física pelo tempo que lhe for necessário. 

**SUPER VELOCIDADE**
 - Os filhos de Ares são extremamente atléticos estando no auge de sua capacidade física independente de quão velho esteja podendo estar tão velho mas ainda ser capaz de se mover como um jovem de quinze anos. Sua capacidade atlética também se estende ao seu organismo demorando muitas horas ou mesmo dias para que seu vigor se esgote, tendo uma equivalência a animais selvagens, trabalhando bem mesmo sobre desnutrição extrema.

**SUPER SALTO**
 - É a capacidade atlética do filho de Ares de realizar saltos grandiosos. Portando de um corpo plenamente capaz de realizar tais saltos até mesmo usando dessa capacidade para causar destruições e massas em um espaço.

**SENTIDOS AGUÇADOS**
-Os filhos de Ares possuem seus cinco sentidos aperfeiçoados ao máximo, permitindo que os mesmos detectem praticamente tudo à sua volta, desde o mais simples dos odores aos maiores cheiros a sua volta, tendo sentidos tão grandiosos que rivalizam até mesmo com grandiosas feras selvagens.

**RESISTÊNCIA FISICO-MENTAL**
- Os filhos de Ares possuem um organismo biológico e uma mente aprimorados ao auge atingindo uma superioridade mental e física que os tornam simplesmente inigualável em comparação a seres humanos comuns e até mesmo uma pequena minoria de semideuses}{footer:Staff - $serverName:$serverIcon}}{newEmbed:{author:$serverName:$serverIcon}{title:Habilidades Ativas - Filhos(as) de Ares}{description:**INTENÇÃO ASSASINA (Habilidade Base)**
 - É a capacidade passiva do filho de Ares de externalizar sua intenção assassina e sádica contra os indivíduos a sua volta, embora não seja capaz de distinguir aliados de inimigos essa capacidade age projetando uma aura avermelhada induzindo diretamente aqueles em volta para uma ilusão consciente.

**O QUE É SEU É MEU (Habilidade Base)**
 - É a capacidade consciente do filho de Ares de se alimentar de conflitos e guerras a sua volta sendo capaz de drenar as energias vitais e divinas dos indivíduos a sua volta presentes no conflito ou mesmo na própria guerra. Tal capacidade age de maneira consciente permitindo que a prole possa definir quem é ou não é afetado.

**ESCUDO ENERGÉTICO (Maestria Baixa)**
 - É a capacidade do filho do Deus da Guerra de projetar um belíssimo escudo energético a sua frente, esse grandioso escudo normalmente é capaz de assumir quaisquer tamanhos imaginados pela prole e até mesmo sua largura ou comprimento é controlado pela imaginação da mesma. 

**ARMAS DE ARES (Maestria Média)**
 - É a capacidade do filho de Ares de projetar armas divinas (brancas ou de fogo), essas armas possuem capacidades divinas sendo na verdade inúmeras armas colecionadas por seu pai que ficam retidas em um espaço inacessível para outros seres divinos, naturalmente quando o mesmo deseja uma delas essas armas são invocadas e equipadas ao mesmo.

**CAMPO DE GUERRA (Maestria Alta)**
 - Sendo filhos do Deus da Guerra, sendo naturalmente guerreiros natos, afinal Ares representa os aspectos mais sanguinários da Guerra, suportando e lidando com os mais diversos campos de batalha e sempre se sobressaindo com perfeição nestes. Tal capacidade permite ao filho de Ares manifestar sua energia em um raio delimitado criando uma cúpula imperceptível e indetectável. Aqueles que estão fora da cúpula acabam não conseguindo sequer sentir ou mesmo perceber o que passa dentro do local, sendo que ataques proferidos de fora são refletidos novamente para seus conjuradores. Já aqueles de dentro não conseguem perceber o que há fora da cúpula e nem mesmo escapar desta. 

A principal finalidade desta cúpula é permitir ao filho de Ares exercer um certo controle geográfico sobre o campo de guerra conseguindo alterar todos os aspectos físicos existentes no mesmo podendo até mesmo modificar estes podendo tornar uma região desértica, uma área tomada por um frio equiparado ao da Antártida, ou até mesmo tornar o ambiente semelhante a um vulcão em erupção repleto de larva. Tal capacidade ainda permite ao mesmo induzir climas ruins com chuvas e raios, lamas, areias movediças por exemplo. Seu controle espacial se limita apenas a alterar sua posição espacial simulando os efeitos de teleporte instantâneo.

**EXÉRCITO DOS ESQUECIDOS (Maestria Máxima)**
 - Usando máximo de seu poder, agora as proles de ares podem invocar um exército de guerreiros que antigamente lutaram ao lado de seu pai, todos eles lutarão ao lado da prole, mesmo sendo mais fracos que ela, como guerreiros comuns.}{footer:Staff - $serverName:$serverIcon}};;;all;true]
  $onlyIf[$interactionData[values[0]]==ares]
`
  }, {
    //Atena
    name: "poderes",
    type: "interaction",
    prototype: "selectMenu",
    code: `
  $interactionReply[;{newEmbed:{author:$serverName:$serverIcon}{title:Habilidades Passivas - Filhos(as) de Atena}{description:**SABEDORIA ANCESTRAL**
 - Assim como sua mãe, as proles de Atena são incrivelmente inteligentes. Sabendo de coisas que aconteceram a muito tempo atrás.

**POLIGLOTISMO**
 - Com o passar do tempo, o cérebro do filho de Athena vai ser tornando mias desenvolvido e anormal dando a ele capacidade de reconhecer qualquer que seja o idioma, a runa, escritos antigos, códigos secretos, magias etc.

**PONTARIA CERTEIRA**
 - O filho de Athena possui uma alta precisão para realizar arremessos seja qual for o objeto a ser lançado. Será basicamente impossível o alvo desviar já que a prole consegue calcular sabiamente e prever sua movimentação.

**INTELIGÊNCIA SOBRE-HUMANA**
- Os filhos de Atena naturalmente herdam o grande intelecto de seu pai herdando uma grande sabedoria que lhes confere um melhoramento de suas capacidades cognitivas e sensoriais.

**PROTEÇÃO MENTAL**
Consiste na capacidade que o filho de Atena tem de ser resistente a ataques mentais}{footer:Staff - $serverName:$serverIcon}}{newEmbed:{author:$serverName:$serverIcon}{title:Habilidades Ativas - Filhos(as) de Atena}{description:**MALDIÇÃO DE ATENA (Habilidade Base)**
 - Os filhos de Atena, assim como sua mãe possuem a capacidade de amaldiçoar o adversário:

Maldição do Medo – O adversário sente um medo profundo

Maldição da Dor – O adversário sentirá uma dor em um dos membros, afetando um pouco seu movimento com o membro escolhido.

Maldição do Azar – O adversário terá menos probabilidade de executar perfeitamente suas ações.

Maldição da Incapacidade – O adversário será incapaz de usar um poder, a sua escolha.

**APRIMORAR ARMAMENTO (Habilidade Base)**
 - Durante uma batalha, a prole erguerá sua arma aos céus e fará uma reza de alguns segundos para sua mãe. Isto fará com que a arma utilizada pelo filho de Atena seja revestida por um brilho dourado e adquira benefícios que amplificaram sua capacidade de combate. 

**CANÇÃO DA NOITE (Maestria Baixa)**
 -O semideus consegue reproduzir um estímulo sonoro bastante similar ao canto de uma coruja, utilizando este artifício para atordoar, enlouquecer, fazer os inimigos voltassem contra si mesmos, baixar a guarda ou até se machucar.

**LANÇA SAGRADA (Maestria Média)**
 - O filho de Athena poderá invocar uma antiga lança pertencente a sua  mãe. A lança é fundida a base de dois minérios: ouro imperial e bronze celestial representando as duas faces da Deusa (Minerva e Athena). A lança poderá ser lançada a uma distancia muito incomum em relação a outras lanças adquirindo um brilho dourado ao ser arremessado. Além disso, a lança pode ser usada para ferir seres divinos.

**AURA ESMAGADORA (Maestria Alta)**
 - Durante uma batalha, a prole poderá solicitar a própria deusa para que a abençoe. Tal benção será manifestada através de uma aura dourada que tomará conta de todo o corpo da prole garantindo-a uma força descomunal que poderá ser utilizada para esmagar coisas, segurar objetos pesados e até saltar a uma altura considerável.

**GUERREIRO DA MENTE (Maestria Máxima)**
 - Filhos(as) de Atena liberam o guerreiro perfeito que sua mãe criou quando os fez, ganhando um bônus em velocidade, dano e defesa, um bônus de +3 em cada. Além disso, se tornam imunes a dor e podem durar mais tempo em campo de batalha do que seus companheiros.}{footer:Staff - $serverName:$serverIcon}};;;all;true]
  $onlyIf[$interactionData[values[0]]==atena]
`
  }, {
    //Apolo
    name: "poderes",
    type: "interaction",
    prototype: "selectMenu",
    code: `
  $interactionReply[;{newEmbed:{author:$serverName:$serverIcon}{title:Habilidades Passivas - Filhos(as) de Apolo}{description:**APTIDÃO AS ARTES**
 - Filhos(as) de Apolo são grandes artistas! Eles cantam, dançam e pintam perfeitamente!

**ARCO E FLECHA**
 - Filhos(as) de Apolo são grandes arqueiros naturais, tem uma incrível facilidade de manusear a arma e um grande potencial.

**BRILHO NO ESCURO**
 - Filhos(as) de Apolo brilham no escuro.

**MEDO DE COBRAS**
 - Filhos(as) de Apolo sentem um medo incontrolável de cobras graças a uma maldição.}{footer:Staff - $serverName:$serverIcon}}{newEmbed:{author:$serverName:$serverIcon}{title:Habilidades Ativas - Filhos(as) de Apolo}{description:**MALDIÇÃO DAS RIMAS (Habilidade Base)**
 - Filhos(as) de Apolo podem amaldiçoar outras pessoas a rimar freneticamente por algum tempo.

**CURA DIVINA (Habilidade Base)**
 - Filhos(as) de Apolo podem recitar uma oração ao seu pai, curando a si mesmo ou a aliados.

**AUDIOCINESE (Habilidade Base)**
 - Filhos(as) de Apolo nascem com a capacidade de controlar as ondas sonoras como bem entenderem.

**CONTROLE SOBRE A LUZ (Maestria Baixa)**
 - Filhos(as) de Apolo podem controlar a luz, mas sempre de uma forma inferior a fotocinese completa dos filhos de Íris.

**FLECHA SOLAR (Maestria Média)**
 - Filhos(as) de Apolo conseguem encantar flechas, fazendo elas serem tomadas por um incrível brilho, que pode cegar ou queimar os inimigos acertados.

**BENÇÃO SOLAR (Maestria Alta)**
 - Filhos(as) de Apolo podem fazer uma oração ao seu pai, que faz com que seu arco se banhe de luz e poder, aumentando sua dano em +3.

**BENÇÃO DOS GÊMEOS ARQUEIROS (Maestria Máxima)**
 - Filhas de Apolo podem fazer uma oração a Ártemis e ao seu pai, Apolo, assim ganhando a benção dos gêmeos arqueiros, que lhes concede a habilidade de controlar os animais utilizando da música. Tal habilidade só está disponível para as filhas e não os filhos.

**BENÇÃO DAS MÚLTIPLAS FLECHAS (Maestria Máxima)**
 - Filhos de Apolo, por outro lado, podem invocar a benção máxima de seu pai, que lhes concede a habilidade de multiplicar suas flechas, além de ganhar um bônus em seu dano de +5.}{footer:Staff - $serverName:$serverIcon}};;;all;true]
  $onlyIf[$interactionData[values[0]]==apolo]
`
  }, {
    //Hefesto
    name: "poderes",
    type: "interaction",
    prototype: "selectMenu",
    code: `
  $interactionReply[;{newEmbed:{author:$serverName:$serverIcon}{title:Habilidades Passivas - Filhos(as) de Hefesto}{description:**IMUNIDADE AO FOGO**
 - Filhos(as) de Hefesto são imunes ao fogo, o calor das forjas percorre por suas veias!

**SENSIBILIDADE DE MÁQUINA**
 - Filhos(as) de Hefesto podem detectar falhas no minério de metal e identificar o tipo de maquinário e usá-lo pelo toque.

**APTIDÃO PARA MÁQUINAS**
 - Filhos(as) de Hefesto podem operar máquinas que nunca se quer tocaram antes!

**A LÍNGUA DAS MÁQUINAS**
 - Filhos(as) de Hefesto podem se comunicar com máquinas, quaisquer que sejam!

**ESPECIALIZAÇÃO EM MÁQUINAS**
 - Filhos(as) de Hefesto podem voar instintivamente ou dirigir habilmente qualquer veículo mecânico, incluindo trens, helicópteros e até carros!}{footer:Staff - $serverName:$serverIcon}}{newEmbed:{author:$serverName:$serverIcon}{title:Habilidades Ativas - Filhos(as) de Hefesto}{description:**PIROCINESE (Habilidade Base)**
 - Filhos(as) de Hefesto tem literalmente o calor das forjas em seu sangue! Eles(as) podem controlar o fogo como bem entenderem, ganhando algumas habilidades especiais além disso.

**TECNOCINESE (Habilidade Base)**
 - Filhos(as) de Hefesto podem manipular máquinas animando-as fisicamente ou controlando-as como bonecos ou se comunicando com máquinas, tecnologia, lâmpadas, vácuos, ou qualquer outra máquina.

**SENHOR BOLA DE FOGO (Maestria Baixa)**
 - Filhos(as) de Hefesto podem invocar bolas de lava ao seu redor, que giram como um escudo, servindo para ataque também.

**FOGO SUPERAQUECIDO (Maestria Média)**
 - Filhos(as) de Hefesto podem fazer seu fogo chegar em níveis absurdos, queimando e derretendo praticamente qualquer coisa.

**BENÇÃO DAS FORJAS (Maestria Alta)**
 - Filhos(as) de Hefesto podem aumentar o seu próprio dano e o dano de seus aliados por +4 durante um turno.

**FOGO INFERNAL (Maestria Máxima)**
 - Filhos(as) de Hefesto podem invocar todas suas energias, fazendo com que suas chamas cheguem em seu ápice, podendo derreter até diamantes.}{footer:Staff - $serverName:$serverIcon}};;;all;true]
  $onlyIf[$interactionData[values[0]]==hefesto]
`
  }, {
    //Afrodite
    name: "poderes",
    type: "interaction",
    prototype: "selectMenu",
    code: `
  $interactionReply[;{newEmbed:{author:$serverName:$serverIcon}{title:Habilidades Passivas - Filhos(as) de Afrodite}{description:**PERÍCIA COM CHICOTE**
 - O filho de Afrodite possui um manejo elevado com chicote e, além disso, é totalmente hábil em fazer manobras incríveis e incomuns com o mesmo, podendo envolver um membro específico do corpo de seus adversários com o chicote para comprometer sua respectiva movimentação.

**SENTIMENTOS AGUÇADOS**
 - Como Afrodite é a deusa do amor, os sentimentos de seus filhos em relação às pessoas são bastante aguçados. Esse poder possibilita os filhos de Afrodite a emitir sentimentos em outras pessoas, sejam eles positivos ou negativos.

**VÔO DO CISNE**
 - Esse poder possibilita aos filhos de Afrodite dá altos pulos ou flutuar por algum tempo.

**FASCINAÇÃO**
 - Causa um efeito de fascinação em todos ao seu redor. Monstros e inimigos fracos não poderão atacar enquanto estiverem sob o efeito desta habilidade, mas o efeito será anulado se você sofrer algum dano por quem não tenha sido vitimado pelo poder.}{footer:Staff - $serverName:$serverIcon}}{newEmbed:{author:$serverName:$serverIcon}{title:Habilidades Ativas - Filhos(as) de Afrodite}{description:**UNHAS RETRÁTEIS (Habilidade Base)**
 - Os filhos de Afrodite conseguem fazer suas unhas crescerem alguns centímetros e ficarem tão resistentes quanto ferro ou ao diamante, sendo muito eficientes para atacar os adversários.

**PÉTALAS (Habilidade Base)**
 - Os filhos de Afrodite podem fazer com que pétalas comecem a cair ao redor do inimigo, para distraí-lo.

**LEVE COMO PENA (Maestria Baixa)**
 - Conseguem encantar objetos de pequeno porte, como uma adaga e fazer com que a mesma flutuem e sigam suas instruções mentalmente.

**MÁSCARA DA INVEJA (Maestria Média)**
 - Seu personagem consegue se transformar perfeitamente em outras pessoas. Vale ressaltar que a voz fica igual e o prazo de duração se estende para 10 minutos.

**TELEPATIA (Maestria Média)**
- Os filhos de Afrodite com esse nível conseguem se comunicar entre si, pois possuem muito amor pelo outro.

**AURACINESE (Maestria Alta)**
É a capacidade de ver e influenciar plenamente a aura de uma pessoa, sendo esta a energia mística, divina ou não, que cada indivíduo exala, sua interação com a Névoa, que existe junto ao sujeito desde que ele nasceu. De maneira defensiva, pode ser usada para ocultar auras, mudá-las e mascará-las, majoritariamente como forma de ocultação. De maneira ofensiva, é possível corromper auras alheias, bloqueando certos poderes, entre diversos usos. Consulte um ADM quanto a extensão.

**PROJEÇÃO ILUSÓRIA (Maestria Alta)**
- Você tem o poder de gerar imagens ilusórias a sua escolha. Podem ser iguais a você, ou ao oponente, ou imitar criaturas, monstros, etc. Eles causarão dano real, mas são apenas uma forma de energia mental, e qualquer golpe os desfaz.

**PAROLA (Maestria Máxima)**
- Você poderá exigir uma negociação, uma conversa, com o seu inimigo. Ele é obrigado a te escutar e a estabelecer uma conversa pacífica com você, mas nenhum dos lados tem permissão de atacar durante a duração da parola. Nada aqui é garantido, apenas a conversa.}{footer:Staff - $serverName:$serverIcon}};;;all;true]
  $onlyIf[$interactionData[values[0]]==afrodite]
`
  }, {
    //Hermes
    name: "poderes",
    type: "interaction",
    prototype: "selectMenu",
    code: `
  $interactionReply[;{newEmbed:{author:$serverName:$serverIcon}{title:Habilidades Passivas - Filhos(as) de Hermes}{description:**ATLETA DIVINO**
 - A prole de Hermes possui capacidades sobre-humanas em questão de elasticidade, agilidade e acrobacia.

**ELOQUÊNCIA DE LINHAGEM**
 - Filhos(as) de Hermes herdam a capacidade de seu pai de fala cativante, negociação única e raciocínio comerciante.

**POLIGLOTA NATO**
 - Perícia Idiomática I: Por Hermes ser um deus viajante deve saber várias línguas diferentes, sendo assim com essa habilidade, o semideus fala dois idiomas além de sua língua natal.
- Ofidioglota: Lhe permite falar com serpentes de todas as espécies. A maioria lhe respeita, a não ser que se trate de animais lendários ou amaldiçoados.

**VIAJANTE INDOMÁVEL**
 - Hermes é o deus dos viajantes, é o mensageiro dos deuses e representante da astronomia. Por conta disso ele consegue se localizar com facilidade, usando os astros, como se fossem uma bússola humana.}{footer:Staff - $serverName:$serverIcon}}{newEmbed:{author:$serverName:$serverIcon}{title:Habilidades Ativas - Filhos(as) de Hermes}{description:**ADAGA BUMERANGUE (Habilidade Base)**
 - Seu personagem pode jogar a Adaga como um bumerangue, a fazendo atingir algum objeto e retornar à sua mão, caso não haja empecilhos no caminho

**BARGANHA (Habilidade Base)**
 - Usufruindo de sua trapaça, seu personagem inicia um falatório que confunde quem o escuta, desorientando o alvo.

**GOLPE SUPERSÔNICO (Maestria Baixa)**
 - Podem exercer ondas de choque poderosas que viajam na velocidade sonora através de vácuos de ar.

**INFILTRADO (Maestria Média)**
 - Os filhos de Hermes são ladrões por natureza, podendo ficar inaudíveis por três turnos.

**MENSAGEM DE ÍRIS (Maestria Média)**
 - Por Íris e seu pai trabalharem juntos, um pequeno arco-íris se formará na sua frente quando desejar, não importa a situação. Você poderá mandar uma Mensagem de graça

**AMPLIFICADOR CINÉTICO (Maestria Alta)**
 - Desde o início do combate, acumula energia de golpes recebidos, desta forma, quando desejar, pode despejar essa tal energia em golpes concentrados, criando um maior impacto.

**LÂMINAS VOADORAS (Maestria Máxima)**
 - Os filhos de Hermes podem invocar adagas espectrais que se lançam contra seus oponentes. Seu dano é o mesmo de uma adaga física e raramente errarão o alvo, já que recebem +3 de bônus no roll.}{footer:Staff - $serverName:$serverIcon}};;;all;true]
  $onlyIf[$interactionData[values[0]]==hermes]
`
  }, {
    //Dionísio
    name: "poderes",
    type: "interaction",
    prototype: "selectMenu",
    code: `
  $interactionReply[;{newEmbed:{author:$serverName:$serverIcon}{title:Habilidades Passivas - Filhos(as) de Dionísio}{description:**UM ÓTIMO SISTEMA IMUNOLÓGICO**
 - Filhos de Dionísio possuem uma resistência alcoólica extremamente alta, podendo ingerir grande quantidades de álcool sem demonstrar nenhum sinal de que chegou ao seu limite. Graças a isso o semideus consegue tirar proveito disso podendo se recuperar de ferimentos graves.
 
**DANÇA MALUCA**
 - A prole de Dionísio é um ótimo dançarino, podendo utilizar isso contra seus oponentes criando um estilo de luta próprio. A prole consegue fazer todos que estiverem próximo a ela sentirem uma louca vontade de dançar. Mesmo que estejam em uma situação ruim, péssima ou boa. Por seus oponentes não terem o costume de dançar (e não terem um corpo flexível) começaram a sentir dores na coluna podendo até mesmo a quebrar caso façam movimentos errados.

**CANTIGA DA RESSACA**
 - Após proferir a cantiga abaixo, o adversário será submisso a alto teor alcoólico, tendo seus sentidos embaçados, completamente desnorteado, consequentemente sem senso de direção exato. É propício este sofrer com fortes quedas e cambaleios. Necessário duas rodadas para a conclusão dos efeitos, sem exceção.''Rodeia Baco, as Mênades Louras, Buscai em Dionísio, a Benção das Loucas''

**AROMA AGRADÁVEL**
 - O filho de Dionísio expele um aroma bastante agradável que de inicio tem como principal efeito atrair a atenção de pessoas aos arredores, podendo causar efeitos variados. }{footer:Staff - $serverName:$serverIcon}}{newEmbed:{author:$serverName:$serverIcon}{title:Habilidades Ativas - Filhos(as) de Dionísio}{description:**MANIPULAÇÃO DE ÁLCOOL (Habilidade Base)**
 - A prole pode criar, formar e manipular o álcool, bebidas alcoólicas, incluindo cervejas, vinhos e bebidas espirituosas. Também podendo usar essa habilidade para muitos outros fatores, podendo controlar sua textura, seu sabor, seu gosto, além de poder manipular outros tipos de álcool como o etanol, metanol, o álcool anidro e entre outros tipos (também podendo modificar suas classificações como desejar).

**CONTROLE DE VINHAS (Habilidade base)**
 - Possui a capacidade de fazer brotar vinhas/videiras de solos férteis ou não, além de adquirir um breve controle sobre elas que podem prender qualquer oponente ou até mesmo exalar um aroma para reanimar plantas recém mortas através da força mental.

**NÉVOA DA AMNÉSIA (Maestria Baixa)**
 - A prole de Dionísio é capaz de manifestar uma névoa roxa semelhante a coloração do vinho que começará a se espalhar pelo local onde estão afetando o oponente fazendo este se esquecer completamente do que iria fazer, deixando a prole sem poder atacar por 2 rodadas.

**ARTE BEBUM (Maestria Média)**
 - As proles de Dionísio poderão invocar uma garrafa de vinho em suas mãos, que ao beber ela até chegar ao fim, a prole terá todas as suas capacidades físicas bufadas. A prole entrará em uma estado onde se encontrará bêbada, porém isso lhe beneficiará tornando seus movimentos mais letais, mais ágeis, e imprevisíveis. Uma energia sinistra rodeará o corpo da prole, essa energia possuirá o mesmo bafo horrível que a prole possui causando mal estar naqueles que se aproximarem.
 
**ANIMAL NATURAL (Maestria Alta)**
 - Seu personagem pode virar um animal e adquirir suas habilidades naturais (não podendo usar nenhum poder passivo ou ativo) (Curto período de tempo, animal básico)

**AURA DE DIONÍSIO (Maestria Máxima)**
 - Filhos(as) de Dionísio poderão criar uma aura densa roxa que deixará a todos que lá entrarem com tontura, enjoo, delirando e perderá totalmente o sentido da realidade, em contrapartida, os filhos de Dionísio ali presentes terão suas feridas curadas e ficarão mais fortes e ágeis, ganhando +5 em força e agilidade.}{footer:Staff - $serverName:$serverIcon}};;;all;true]
  $onlyIf[$interactionData[values[0]]==dionisio]
`
  }]
}