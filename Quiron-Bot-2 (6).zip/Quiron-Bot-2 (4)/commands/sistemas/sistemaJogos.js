
{
  module.exports = [
    {
      name: "sistJog",
      code: `
$author[$serverName;$serverIcon]
$title[Sistema de Jogos]
$description[No Acampamento Meio-Sangue existem várias atividades, jogos criados há muito tempo, para incentivar o espírito de batalha dos semideuses e faze-los usarem suas habilidades, durante essas atividades os jogadores terão de se arriscar e poderão ganhar mais pontos do que em uma missão comum, tendo que utilizar sua mente e seus poderes de forma estratégica.]
$addField[🧨・Campistas VS Caçadoras;\`\`\`25-30 pontos - Uma série de competições amigáveis entre os Campistas e as Caçadoras de Ártemis.\`\`\`]
$addField[🏹・Caçadoras de Ártemis;\`\`\`20-25 pontos - Uma série de competições para testar as campistas, valendo uma vaga no grupo das Caçadoras de Ártemis.\`\`\`]
$addField[🚩・Caça a Bandeira;\`\`\`10-20 pontos - Duas equipes são formadas, a equipe azul e a equipe vermelha, ambas com o objetivo de capturar a bandeira inimiga, esse jogo geralmente se passa no riacho e utiliza-se bastante do combate com espadas.\`\`\`]
$addButton[1;❓ Pedir Ajuda;link;https://discord.com/channels/1086836441604177960/1087474866791391332;no]
$addButton[1;📃 Conferir Atributos;link;https://discord.com/channels/1086836441604177960/1086836448164061237;no]
$image[https://i.imgur.com/nICRA0K.gif]
$footer[Staff - 🔱 • Olimpianos: Crônicas Meio-Sangue - RP;$serverIcon]
            `
    }
  ]
}