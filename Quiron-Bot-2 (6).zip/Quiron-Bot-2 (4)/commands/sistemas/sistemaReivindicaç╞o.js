
{
  module.exports = [
    {
      name: "sistRei",
      code: `
$author[$serverName;$serverIcon]
$title[Sistema de Reivindicação]
$description[Os deuses do Olimpo tem vários filhos espalhados pelo mundo todo, muitos deles vão ao acampamento meio-sangue, mas, para serem movidos para o chalé de seu verdadeiro pai ou sua verdadeira mãe, eles tem que ser reivindicados pelo mesmo. Esse processo pode levar pouco tempo ou até mesmo meses, alguns semideuses nunca se quer foram reivindicados, esses semideuses não reivindicados ficarão todo seu tempo no Chalé de Hermes, até que um dia seus pais ou mães resolvam reivindica-los.
\`\`\`・Como posso ser reivindicado(a)? Bom, para ser reivindicado, terá de esperar até o pai ou mãe do seu personagem reivindica-lo, o que não deve demorar em alguns casos, ainda mais se você fizer algo que agrade eles, como um grande feitiço ou uma grande demonstração de poder.\`\`\`
\`\`\`・Os Personagens reivindicados terão, consequentemente, mais conhecimento sobre si mesmo, podendo treinar para melhorar aquilo que se é bom, fazendo assim eles mais poderosos que semideuses não reivindicados.\`\`\`
\`\`\`・Os personagens reivindicados podem ganhar presentes de seus parentes divinos por terem se mostrado dignos de serem reivindicados, mesmo que seja só  ter sobrevivido, um item ou bênção que melhorará tudo aquilo que o personagem tem de melhor!\`\`\`]
$addButton[1;❓ Pedir Ajuda;link;https://discord.com/channels/1086836441604177960/1087474866791391332;no]
$addButton[1;💪 Conferir Poderes;link;https://discord.com/channels/1086836441604177960/1086836444808622141;no]
$addButton[1;🧬 Conferir Raças;link;https://discord.com/channels/1086836441604177960/1086836444808622140;no]
$image[https://i.imgur.com/ec7UC8p.gif]
$footer[Staff - 🔱 • Olimpianos: Crônicas Meio-Sangue - RP;$serverIcon]
            `
    }
  ]
}