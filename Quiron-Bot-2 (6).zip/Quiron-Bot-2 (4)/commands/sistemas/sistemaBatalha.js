module.exports = {
  name: "sistBat",
  code: `
$author[$serverName;$serverIcon]
$title[Sistema de Vida]
$description[As batalhas são bastante comuns na vida de um semideus e para torna-las justas, utilizamos um sistema de dados, assim como o RPG de Mesa. Lembrando, caso o Mestre de Mesa ache que a batalha está sendo injusta ou que não faz sentido, ele ou ela poderá anular a batalha para evitar de personagens ficarem matando os outros sem motivo algum.]
$addField[🎲・Rolls;> \🗡️・Para atacar o seu inimigo, deves utilizar o comando de roll de acordo com a maestria do ataque para definir o dano que você irá causar, veja abaixo:
> ─ ***Habilidade Base:*** \`1d6\`
> ─ ***Maestria Baixa:*** \`2d6\`
> ─ ***Maestria Média:*** \`2d8\`
> ─ ***Maestria Alta:*** \`3d6\`
> ─ ***Maestria Máxima:*** \`4d8\`
> 
> \🛡️・Para se defender, você utilizará o mesmo roll que seu inimigo utilizou, o dano que você vai tomar é a subtração do roll do seu inimigo, com o seu. 
> **Exemplo:** Eu te ataco com \`1d6\` e tiro \`5\`, você se defende com \`1d6\` e tira \`4\`, logo você irá tomar \`1\` de dano.]
$addButton[1;❓ Pedir Ajuda;link;https://discord.com/channels/1086836441604177960/1087474866791391332;no]
$image[https://media.tenor.com/v4XTlLWigj4AAAAC/fighting-annabeth.gif]
$footer[Staff - 🔱 • Olimpianos: Crônicas Meio-Sangue - RP;$serverIcon]
`
}