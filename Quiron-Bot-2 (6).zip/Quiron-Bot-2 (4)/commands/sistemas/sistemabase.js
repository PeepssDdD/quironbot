
{
  module.exports = [{
    name: "aaa",
    code: `
$author[$serverName;$serverIcon]
$title[Sistema de Missões]
$description[Feito para te ajudar a conquistar mais pontos de atributos e ajudar a trama atual a se desenvolver, o Sistema de Missões é dividido em vários tipos de missões, que tem suas determinadas recompensas e perigos.]
$addField[🔥・Comum;5-10 pontos - Possibilidade de ter pequenos machucados.]
$addField[⚡・Perigosa;15-20 pontos - Possibilidade de ter machucados, quebra de ossos mas nunca morte.]
$addField[💥・Mortal;25-30 pontos - Possibilidade de ter machucados graves, quebra de ossos e até morte.]
$addField[☄️・Perigo Mundial;35-50 pontos - Machucados graves, talvez cicatrizes, talvez partes arrancadas, talvez quebra de ossos e morte.]
$addButton[1;❓ Pedir Ajuda;link;https://discord.com/channels/1086836441604177960/1087474866791391332;no]
$addButton[1;🌟 Sugerir uma Missão;link;https://discord.com/channels/1086836441604177960/1086836444498239535;no]
$addButton[1;Tipos de Missões;success;tiposMis;no;🗡️]
$image[https://i.imgur.com/GrsLxSE.gif]
$footer[Staff - 🔱 • Olimpianos: Crônicas Meio-Sangue - RP;$serverIcon]
`
  }, {
    name: "tiposMis",
    prototype: "button",
    type: "interaction",
    code: `
    $interactionReply[;{newEmbed:{author:$serverName:$serverIcon}{title:Tipos de Missões}{footer:Staff - $serverName:$serverIcon}{color:#99abbe}};;;all;true]
`
  }]
}