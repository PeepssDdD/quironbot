
{
  module.exports = [
    {
      name: "sistNiv",
      code: `
$author[$serverName;$serverIcon]
$title[Sistema de Níveis]
$description[O Sistema de Níveis é um sistema que anda de mãos dadas com as <#1019661124104368251>, com eles dois você evoluirá e desbloqueará novas habilidades e presentes. Você sobe de nível a cada 5 pontos de atributos aplicados, você pode conferir mais sobre eles no <#1086836448164061237>.]
$addField[🏅・Nível 40 - Herói;**\`\`\`・O Herói é aquele que possui centenas de pontos e experiência, já está em sua jornada à anos e possui as seguintes vantagens:\`\`\`**\`\`\`・Desbloqueia a maestria máxima do seu personagem.
・Ganha acesso direto para falar com seu parente divino.
・Ganha um desejo, que vai ser realizado pelos Olimpianos, só lembre de não abusar.
・Se torna oficialmente um herói, podendo encerrar sua vida no acampamento e entrar em uma nova vida de aventuras.\`\`\`]
$addField[⚔️・Nível 30 - Guerreiro;**\`\`\`・O Guerreiro é aquele que possui muitos pontos e experiência, já está em sua jornada à um longo e durador tempo e possui as seguintes vantagens:\`\`\`**\`\`\`・Desbloqueia a maestria alta do seu personagem.
・Desbloqueia a possibilidade de se tornar o Conselheiro de seu chalé.
・Ganha uma benção de seu parente divino, uma habilidade.\`\`\`]
$addField[🗡️・Nível 20 - Campista;**\`\`\`・O Campista é aquele que já possui mais experiência e pontos, já está em sua jornada à bastante tempo e possui as seguintes vantagens:\`\`\`**\`\`\`・Desbloqueia a maestria média do seu personagem.
・Ganha um objeto mágico de seu parente divino, podendo ser desde um boné da invisibilidade até um escudo protetor.\`\`\`]
$addField[🏹・Nível 10 - Novato;**\`\`\`・O Novato é aquele que acabou de embarcar em sua jornada pelo Acampamento, este tem poucas vantagens e poucos pontos de atributos, possuindo as seguintes vantagens:\`\`\`**\`\`\`・Desbloqueia a maestria baixa do seu personagem.\`\`\`]
$addButton[1;❓ Pedir Ajuda;link;https://discord.com/channels/1086836441604177960/1087474866791391332;no]
$addButton[1;💎 Conferir Maestrias;link;https://discord.com/channels/1086836441604177960/1086836448164061242;no]
$image[https://i.imgur.com/yEGOYm8.gif]
$footer[Staff - 🔱 • Olimpianos: Crônicas Meio-Sangue - RP;$serverIcon]
            `
    }
  ]
}