
{
  module.exports = [
    {
      name: "sistMae",
      code: `
$author[$serverName;$serverIcon]
$title[Sistema de Maestrias]
$description[O sistema de maestrias existe para controlar os poderes dos personagens, para que tudo fique balanceado, elas são desbloqueadas pelo **SISTEMA DE NÍVEIS** e podem ser divididas em quatro níveis: Maestria Baixa, Maestria Média, Maestria Alta e Maestria Máxima. Após seu personagem atingir certa maestria, ele pode desbloquear habilidades e poderes ou então uma nova extensão dos poderes que ele já tinha.]
$addButton[1;❓ Pedir Ajuda;link;https://discord.com/channels/1086836441604177960/1087474866791391332;no]
$addButton[1;📈 Conferir Níveis;link;https://discord.com/channels/1086836441604177960/1086836448164061238;no]
$image[https://media.tenor.com/nXLWT6puP2MAAAAC/logan-lerman-percy-jackson.gif]
$footer[Staff - 🔱 • Olimpianos: Crônicas Meio-Sangue - RP;$serverIcon]
            `
    }
  ]
}