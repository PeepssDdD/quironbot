module.exports = {
  name: "sistVida",
  code: `
$author[$serverName;$serverIcon]
$title[Sistema de Vida]
$description[O sistema de vida vai medir o estado do seu personagem, quanto mais pontos de vida você tiver, mais saudável ele estará, quanto menos, mais machucado ou caso seu personagem chegue em 0 em vida, ele morrerá. O número da sua vida máxima é baseado em 2 coisas: A base (25 ou 30, dependendo do seu parente divino) e sua constituição (<#1086836448164061237>).]
$addButton[1;❓ Pedir Ajuda;link;https://discord.com/channels/1086836441604177960/1087474866791391332;no]
$addButton[1;🏹 Conferir Sistema de Batalha;link;https://discord.com/channels/1086836441604177960/1086836448164061239;no]
$image[https://media.tenor.com/eLjdkTC46m8AAAAC/percy-jackson-logan-lerman.gif]
$footer[Staff - 🔱 • Olimpianos: Crônicas Meio-Sangue - RP;$serverIcon]
`
}