
{
  module.exports = [{
    name: "sistAtrib",
    code: `
$author[$serverName;$serverIcon]
$title[Sistema de Atributos]
$description[\`\`\`• O Sistema de Atributos é um sistema relacionado as habilidades do seu personagem, sendo elas físicas ou mentais. Esse é um sistema criado para controlar, limitar e melhorar as ações e as interpretações dos players.\`\`\` 
\`\`\`• Para saber mais, clique nos botões abaixo, eles vão mandar uma nova mensagem explicando mais sobre tudo, você também pode clicar no botão de ajuda e pedir ajuda diretamente a staff.\`\`\`]
$addButton[1;❓ Pedir Ajuda;link;https://discord.com/channels/1086836441604177960/1087474866791391332;no]
$addButton[1;Sobre os Atributos;primary;sobreatr;no;🔍]
$image[https://i.imgur.com/EkNy9go.gif]
$footer[Staff - 🔱 • Olimpianos: Crônicas Meio-Sangue - RP;$serverIcon]
`
  }, {
    name: "sobreatr",
    prototype: "button",
    type: "interaction",
    code: `
    $interactionReply[;{newEmbed:{author:$serverName:$serverIcon}{title:Sobre os Atributos}{field:⚔️・Força (FR):\`\`\`É o atributo que se refere a força muscular, isto é, a capacidade muscular do usuário. \`\`\`}{field:🛡️・Constituição (CON):\`\`\`É o atributo que se refere a vida e resistência do usuário.\`\`\`}{field:⚡・Velocidade (VEL):\`\`\`É o atributo que se refere a velocidade de locomoção (KM/H).\`\`\`}{field:🦿・Destreza (DES):\`\`\`É o atributo que se refere a velocidade de reação do usuário.\`\`\`}{field:🤺・Treinamento (TRE):\`\`\`É o atributo que se refere a habilidade do usuário com armas brancas e artes maciais.\`\`\`}{field:🧠・Inteligência (INT):\`\`\`É o atributo que se refere a mente como um todo, principalmente a resistência mental.\`\`\`}{field:🌈・Carisma (CAR):\`\`\`É o atributo que dita a capacidade do seu personagem de enganar outros, coagir pessoas, e conseguir fazer negociações que seriam totalmente injustas para o lado do outro e entre outras coisas.\`\`\`}{footer:Staff - 🔱 • Olimpianos#COLON# Crônicas Meio-Sangue - RP:$serverIcon}{color:#99abbe}};;;all;true]
`
  }]
}
