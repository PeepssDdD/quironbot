module.exports = [{
  name: "set",
  code: `
$color[RANDOM]
$author[$userTag[$authorID];$authorAvatar]
$title[Ponto(s) Setados!]
$description[✔️・ Você setou o(s) ponto(s) de atributos de <@$findUser[$message[1]]> para $message[2]!]

$footer[Setado por $userTag[$authorID];$authorAvatar]
$addTimestamp

$setGlobalUserVar[pontosAtributos;$message[2];$findUser[$message[1]]]

$onlyForRoles[1087794925153828924;❌・ Você não pode utilizar este comando!]
$argsCheck[2;Uso correto: \`!set (Usuário) (Quantidade)\`]
$onlyIf[$isNumber[$message[2]]==true;{"content": "Erro! Você somente pode colocar números!","ephemeral": "true"}]

$suppressErrors
`
}]