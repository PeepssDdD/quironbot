module.exports = {
  name: "ping",
  code: `
🏓 Pong! $pingms
`
}