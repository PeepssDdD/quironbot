module.exports = {
  name: "eval",
  code: `
$eval[$message]
$onlyForIDs[$botOwnerId;]
`
}
