{
  module.exports = [{
  name: "atributos",
  code: `
$if[$message[1]!=;{execute:atributosMarcado};{execute:atributosAutor}]
`
}, {
  name: "atributosAutor",
  type: "awaited",
  code: `
    $author[Personagem de $userTag[$authorID];$authorAvatar]
    $title[1;Atributos de $getUserVar[nomePerso;$authorID]!]
    $description[1;
\`\`\`Informações do Usuário:\`\`\`
> ✨・Pontos de Atributos disponíveis: \`$getGlobalUserVar[pontosAtributos;$authorID]\`

\`\`\`Atributos:\`\`\`
> ⚔️・Força (FOR): \`$getGlobalUserVar[for;$authorID]/100\`
> ❤️‍🩹・Constituição (CON): \`$getGlobalUserVar[con;$authorID]/100\`
> 🦿・Velocidade (VEL) \`$getGlobalUserVar[vel;$authorID]/100\`
> 🏃・Destreza (DES) \`$getGlobalUserVar[des;$authorID]/100\`
> 🤺・Treinamento (TRE): \`$getGlobalUserVar[tre;$authorID]/100\`
> 🧠・Inteligência (INT): \`$getGlobalUserVar[int;$authorID]/100\`
> 🌈・Carisma (CAR):: \`$getGlobalUserVar[car;$authorID]/100\`
]
    $thumbnail[$getUserVar[fotoPerso;$authorID]] 
    $footer[1;Comando executado por $userTag]
    $color[1;RANDOM]
    $addSelectMenu[1;atributos;Escolha em qual atributo quer adicionar um ponto!;1;1;no;Força:Adicione 1 ponto ao atributo Força:for_$authorID;Constituição:Adicione 1 ponto ao atributo Constituição:con_$authorID;Velocidade:Adicione 1 ponto ao atributo Velocidade:vel_$authorID;Destreza:Adicione 1 ponto ao atributo Destreza:des_$authorID;
Treinamento:Adicione 1 ponto ao atributo Treinamento:tre_$authorID;Inteligência:Adicione 1 ponto ao atributo Inteligência:int_$authorID;Carisma:Adicione 1 ponto ao atributo Carisma:car_$authorID]
`
}, {
  name: "atributosMarcado",
  type: "awaited",
  code: `
    $author[Personagem de $userTag[$mentioned[1]];$authorAvatar]
    $title[1;Atributos de $getUserVar[nomePerso;$mentioned[1]]!]
    $description[1;
\`\`\`Informações do Usuário:\`\`\`
> ✨・Pontos de Atributos disponíveis: \`$getGlobalUserVar[pontosAtributos;$mentioned[1]]\`

\`\`\`Atributos:\`\`\`
> ⚔️・Força (FOR): \`$getGlobalUserVar[for;$mentioned[1]]/100\`
> ❤️‍🩹・Constituição (CON): \`$getGlobalUserVar[con;$mentioned[1]]/100\`
> 🦿・Velocidade (VEL) \`$getGlobalUserVar[vel;$mentioned[1]]/100\`
> 🏃・Destreza (DES) \`$getGlobalUserVar[des;$mentioned[1]]/100\`
> 🤺・Treinamento (TRE): \`$getGlobalUserVar[tre;$mentioned[1]]/100\`
> 🧠・Inteligência (INT): \`$getGlobalUserVar[int;$mentioned[1]]/100\`
> 🌈・Carisma (CAR):: \`$getGlobalUserVar[car;$mentioned[1]]/100\`
]
    $thumbnail[$getUserVar[fotoPerso;$mentioned[1]]] 
    $footer[1;Comando executado por $userTag]
    $color[1;RANDOM]
`
}, {
  //Força
  name: "atributos",
  type: "interaction",
  prototype: "selectMenu",
  code: `
  $interactionReply[✔️・ Voce adicionou 1 ponto ao atributo Força!;;;;all;true]  $setGlobalUserVar[for;$sum[$getGlobalUserVar[for;$authorID];1];$authorID] 
$setGlobalUserVar[pontosAtributos;$sub[$getGlobalUserVar[pontosAtributos;$authorID];1];$authorID]
  $onlyIf[$getGlobalUserVar[pontosAtributos;$authorID]!=0;]
  $if[$getGlobalUserVar[pontosAtributos;$authorID]==0;{execute:semPontos}]
  $onlyIf[$interactionData[values[0]]==for_$authorID;]
`
}, {
  //Constituição
  name: "atributos",
  type: "interaction",
  prototype: "selectMenu",
  code: `
  $interactionReply[✔️・ Voce adicionou 1 ponto ao atributo Constituição!;;;;all;true]  $setGlobalUserVar[con;$sum[$getGlobalUserVar[con;$authorID];1];$authorID] 
$setGlobalUserVar[pontosAtributos;$sub[$getGlobalUserVar[pontosAtributos;$authorID];1];$authorID]
  $onlyIf[$getGlobalUserVar[pontosAtributos;$authorID]!=0;]
  $if[$getGlobalUserVar[pontosAtributos;$authorID]==0;{execute:semPontos}]
  $onlyIf[$interactionData[values[0]]==con_$authorID;]
`
}, {
  //Velocidade
  name: "atributos",
  type: "interaction",
  prototype: "selectMenu",
  code: `
  $interactionReply[✔️・ Voce adicionou 1 ponto ao atributo Velocidade!;;;;all;true]  $setGlobalUserVar[vel;$sum[$getGlobalUserVar[vel;$authorID];1];$authorID] 
$setGlobalUserVar[pontosAtributos;$sub[$getGlobalUserVar[pontosAtributos;$authorID];1];$authorID]
  $onlyIf[$getGlobalUserVar[pontosAtributos;$authorID]!=0;]
  $if[$getGlobalUserVar[pontosAtributos;$authorID]==0;{execute:semPontos}]
  $onlyIf[$interactionData[values[0]]==vel_$authorID;]
`
}, {
  //Destreza
  name: "atributos",
  type: "interaction",
  prototype: "selectMenu",
  code: `
  $interactionReply[✔️・ Voce adicionou 1 ponto ao atributo Destreza!;;;;all;true]  $setGlobalUserVar[des;$sum[$getGlobalUserVar[des;$authorID];1];$authorID] 
$setGlobalUserVar[pontosAtributos;$sub[$getGlobalUserVar[pontosAtributos;$authorID];1];$authorID]
  $onlyIf[$getGlobalUserVar[pontosAtributos;$authorID]!=0;]
  $if[$getGlobalUserVar[pontosAtributos;$authorID]==0;{execute:semPontos}]
  $onlyIf[$interactionData[values[0]]==des_$authorID;]
`
}, {
  //Treinamento
  name: "atributos",
  type: "interaction",
  prototype: "selectMenu",
  code: `
  $interactionReply[✔️・ Voce adicionou 1 ponto ao atributo Treinamento!;;;;all;true]  $setGlobalUserVar[tre;$sum[$getGlobalUserVar[tre;$authorID];1];$authorID] 
$setGlobalUserVar[pontosAtributos;$sub[$getGlobalUserVar[pontosAtributos;$authorID];1];$authorID]
  $onlyIf[$getGlobalUserVar[pontosAtributos;$authorID]!=0;]
  $if[$getGlobalUserVar[pontosAtributos;$authorID]==0;{execute:semPontos}]
  $onlyIf[$interactionData[values[0]]==tre_$authorID;]
`
}, {
  //Inteligência
  name: "atributos",
  type: "interaction",
  prototype: "selectMenu",
  code: `
  $interactionReply[✔️・ Voce adicionou 1 ponto ao atributo Inteligência!;;;;all;true]  $setGlobalUserVar[int;$sum[$getGlobalUserVar[int;$authorID];1];$authorID] 
$setGlobalUserVar[pontosAtributos;$sub[$getGlobalUserVar[pontosAtributos;$authorID];1];$authorID]
  $onlyIf[$getGlobalUserVar[pontosAtributos;$authorID]!=0;]
  $if[$getGlobalUserVar[pontosAtributos;$authorID]==0;{execute:semPontos}]
  $onlyIf[$interactionData[values[0]]==int_$authorID;]
`
}, {
  //Carisma
  name: "atributos",
  type: "interaction",
  prototype: "selectMenu",
  code: `
  $interactionReply[✔️・ Voce adicionou 1 ponto ao atributo Carisma!;;;;all;true]  $setGlobalUserVar[car;$sum[$getGlobalUserVar[car;$authorID];1];$authorID] 
$setGlobalUserVar[pontosAtributos;$sub[$getGlobalUserVar[pontosAtributos;$authorID];1];$authorID]
  $onlyIf[$getGlobalUserVar[pontosAtributos;$authorID]!=0;]
  $if[$getGlobalUserVar[pontosAtributos;$authorID]==0;{execute:semPontos}]
  $onlyIf[$interactionData[values[0]]==car_$authorID;]
`
}, {
  name: "semPontos",
  type: "awaited",
  code: `
  $interactionReply[❌・ Você não tem pontos suficientes para essa ação!;;;;all;true]
`
}]}