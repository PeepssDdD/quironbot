module.exports = [{
  name: "reset",
  code: `
$color[RANDOM]
$author[$userTag[$authorID];$authorAvatar]
$title[Personagem Resetado!]
$description[✔️・ Você resetou o personagem de <@$findUser[$message[1]]>!]

$footer[Adicionado por $userTag[$authorID];$authorAvatar]
$addTimestamp

$setGlobalUserVar[for;0]
$setGlobalUserVar[con;0]
$setGlobalUserVar[vel;0]
$setGlobalUserVar[des;0]
$setGlobalUserVar[tre;0]
$setGlobalUserVar[int;0]
$setGlobalUserVar[car;0]

$onlyForRoles[1087794925153828924;❌・ Você não pode utilizar este comando!]
$argsCheck[1;Uso correto: \`!reset (Usuário)\`]

$suppressErrors
`
}]