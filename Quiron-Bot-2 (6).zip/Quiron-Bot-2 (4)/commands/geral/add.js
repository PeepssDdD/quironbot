module.exports = [{
  name: "add",
  code: `
$color[RANDOM]
$author[$userTag[$authorID];$authorAvatar]
$title[Ponto(s) Adicionados!]
$description[✔️・ Você adicionou $message[2] ponto(s) de atributos a <@$findUser[$message[1]]>!]

$footer[Adicionado por $userTag[$authorID];$authorAvatar]
$addTimestamp

$setGlobalUserVar[pontosAtributos;$sum[$getGlobalUserVar[pontosAtributos;$findUser[$message[1]]];$message[2]];$findUser[$message[1]]]

$onlyForRoles[1087794925153828924;❌・ Você não pode utilizar este comando!]
$argsCheck[2;Uso correto: \`!add (Usuário) (Quantidade)\`]
  $onlyIf[$isNumber[$message[2]]==true;{"content": "Erro! Você somente pode colocar números!","ephemeral": "true"}]

$suppressErrors
`
}]