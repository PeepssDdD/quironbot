module.exports = [{
  name: "curar",
  code: `
$color[RANDOM]
$author[$userTag[$authorID];$authorAvatar]
$title[Personagem Curado(a)!]
$description[✔️・ O personagem de <@$findUser[$message[1]]> foi curado em $message[2] ponto(s) de vida!]

$footer[Adicionado por $userTag[$authorID];$authorAvatar]
$addTimestamp

$setUserVar[vidaPerso;$sum[$getUserVar[vidaPerso;$findUser[$message[1]]];$message[2]];$findUser[$message[1]]]

$onlyForRoles[1087794925153828924;❌・ Você não pode utilizar este comando!]
$argsCheck[2;Uso correto: \`-curar (Usuário) (Quantidade)\`]
  $onlyIf[$isNumber[$message[2]]==true;{"content": "Erro! Você somente pode colocar números!","ephemeral": "true"}]

$suppressErrors
`
}]