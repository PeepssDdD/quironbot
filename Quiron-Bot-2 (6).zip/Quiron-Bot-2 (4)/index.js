const aoijs = require("aoi.js");
const { WebhookClient } = require('discord.js');

const bot = new aoijs.Bot({
  token: "MTA4NzQ4MDY5OTUyODkzNzU2NQ.G9ZVHf.3jpl6m6DuGf-dvH4OxST_cp-pfZ2Se85rqZQzQ",
  prefix: "-",
  intents: ["GUILDS", "GUILD_MEMBERS", "GUILD_MESSAGES", "GUILD_MESSAGE_REACTIONS"],
  database: {
    db: require("dbdjs.db"),
    type: "dbdjs.db",
    path: "./database/",
    tables: ["main", "secundary"],
  }
});

//Events
bot.onMessage();
bot.onMessageDelete();
bot.onMessageUpdate();
bot.onInteractionCreate();
bot.onReactionAdd();
bot.onReactionRemove();

//Slash Commands
bot.interactionCommand({
  name: "registrar",
  prototype: "slash",
  code: `
      $if[$getUserVar[nomePerso]==Não Definido;{execute:naoRegistrado};{execute:registrado}]
    `
}); //Registrar
bot.interactionCommand({
  name: "nome",
  prototype: "slash",
  code: `$interactionReply[;{newEmbed:{{title:Novo Nome!}{description: <@$authorID> você acabou de mudar o nome do seu personagem para $slashOption[nome]}{footer:Equipe & Staff - Castelobruxo:$serverIcon}}};;;everyone]
      $setUserVar[nomePerso;$slashOption[nome]]
    `
}); //Nome
bot.interactionCommand({
  name: "avatar",
  prototype: "slash",
  code: `$interactionReply[;{newEmbed:{{title:Nova Foto!}{description: <@$authorID> você acabou de mudar a foto do seu personagem.}{thumbnail:$interactionData[options.resolved.attachments.get("$slashOption[imagem]")?.url]}{footer:Equipe & Staff - Castelobruxo:$serverIcon}}};;;everyone]
      $setUserVar[fotoPerso;$interactionData[options.resolved.attachments.get("$slashOption[imagem]")?.url]]
    `
}); //Avatar

//Awaited Commands
bot.awaitedCommand({
  name: "naoRegistrado",
  code: `$interactionReply[;{newEmbed:{{title:Olá, $slashOption[nome]!}{description: <@$authorID> você criou $slashOption[nome] com sucesso! Agora sempre que você falar em chats de rp você já falará automaticamente com ele(a).}{thumbnail:$interactionData[options.resolved.attachments.get("$slashOption[imagem]")?.url]}{footer:Equipe & Staff - Castelobruxo:$serverIcon}}};;;everyone]
  $setUserVar[nomePerso;$slashOption[nome]]
$setUserVar[fotoPerso;$interactionData[options.resolved.attachments.get("$slashOption[imagem]")?.url]]
  `
}); //Não Registrado
bot.awaitedCommand({
  name: "registrado",
  code: `$interactionReply[;{newEmbed:{{title:Já Registrado!}{description: Você já registrou um personagem.}{footer:Equipe & Staff - Castelobruxo:$serverIcon}}};;;everyone]
  `
}); //Registrado

//Custom Functions
bot.functionManager.createCustomFunction({
  name: "$bruxohook",//FUNCTION NAME
  type: "djs",//TYPE OF THE FUNCTION
  code: async d => {//FETCHING DATA AS D

    const data = d.util.aoiFunc(d);
    const [messageAuthor, id, token, channelID, messageID, name, avatar, message, isReplyMessage, webhookNameMsg, webhookAuthorMsg] = data.inside.splits;
    const webhook = new WebhookClient({ id, token: token.addBrackets() });

    const channel = await d.util.getChannel(d, channelID);

    const msg = await d.util.getMessage(channel, messageID);
    var aurl = [];

    msg.attachments.forEach(attachment => {
      // do something with the attachment
      aurl.push(attachment.url)
    })

    var msgResult = ""

    if (isReplyMessage != "") {
      msg.channel.messages.fetch(isReplyMessage)
        .then(function(messageReply) {
          if (messageReply.content.includes("<:sep_reply:1091897801560047659>")) {
            msgResult = messageReply.content.split("<:sep_reply:1091897801560047659>")[1].replace(`
`, "")
          } else {
            msgResult = messageReply.content
          }
          if (messageReply.webhookId == undefined) {
            webhook.send({
              content: `
> ${msgResult} - [Mensagem](${messageReply.url})
<:sep_reply:1091897801560047659>
${message}`,
              username: name,
              avatarURL: avatar,
              files: aurl
            }).then(messageWebhook => {
              d.client.db.set(d.client.db.tables[1], 'webhookNameMsg', messageWebhook.id, name)
              d.client.db.set(d.client.db.tables[1], 'webhookAuthorMsg', messageWebhook.id, messageAuthor)
            })
          } else {
            webhook.send({
              content: `
> ${msgResult}
${webhookNameMsg} (<@${webhookAuthorMsg}>) - [Mensagem](${messageReply.url})
<:sep_reply:1091897801560047659>
${message}`,
              username: name,
              avatarURL: avatar,
              files: aurl
            }).then(messageWebhook => {
              d.client.db.set(d.client.db.tables[1], 'webhookNameMsg', messageWebhook.id, name)
              d.client.db.set(d.client.db.tables[1], 'webhookAuthorMsg', messageWebhook.id, messageAuthor)
            })
          }
        }
        )
        .catch(console.error);
    } else {
      webhook.send({
        content: message,
        username: name,
        avatarURL: avatar,
        files: aurl
      }).then(messageWebhook => {
        d.client.db.set(d.client.db.tables[1], 'webhookNameMsg', messageWebhook.id, name)
        d.client.db.set(d.client.db.tables[1], 'webhookAuthorMsg', messageWebhook.id, messageAuthor)
      })
    }
    return {
      code: d.util.setCode(data)
    }
  }
});

//Variáveis
bot.variables({
  nomePerso: "Não Definido",
  vidaPerso: 0,
  fotoPerso: "https://i.imgur.com/12wvWQo.png",
  pontosAtributos: 0,
  for: 0,
  con: 0,
  vel: 0,
  des: 0,
  tre: 0,
  int: 0,
  car: 0,
  webhookInfoID: "0",
  webhookInfoToken: "0",
  webhookMessageID: "0",
  webhookNameMsg: "undefined",
  webhookAuthorMsg: "undefined"
});

//Loader
const loader = new aoijs.LoadCommands(bot);
loader.load(bot.cmd, "./commands/geral/");
loader.load(bot.cmd, "./commands/outros/");
loader.load(bot.cmd, "./commands/sistemas/");